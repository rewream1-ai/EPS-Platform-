// preload.js — Electron Preload Script
// Expose APIs sécurisées au renderer process

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  platform: process.platform,
  version: process.versions.electron,
  // Vous pouvez ajouter des APIs personnalisées ici
  // ex: sauvegarde de fichiers, notifications système, etc.
});
