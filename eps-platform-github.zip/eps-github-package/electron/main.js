// ====================================================
// Electron Main Process — EPS Platform
// منصة التربية البدنية والرياضية
// ====================================================

const { app, BrowserWindow, Menu, shell, ipcMain, dialog } = require('electron');
const path = require('path');

// تحديد مسار الملف الرئيسي
const INDEX_HTML = path.join(__dirname, '..', 'index.html');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    title: 'EPS Platform — منصة التربية البدنية والرياضية',
    icon: path.join(__dirname, '..', 'icons', 'icon-256x256.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: true,
      preload: path.join(__dirname, 'preload.js'),
    },
    backgroundColor: '#f0f4ff',
    show: false, // masqué jusqu'au chargement complet
  });

  // Charger l'application HTML locale
  mainWindow.loadFile(INDEX_HTML);

  // Afficher quand prêt (évite le flash blanc)
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  // Ouvrir les liens externes dans le navigateur
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http://') || url.startsWith('https://')) {
      shell.openExternal(url);
    }
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// ── Menu personnalisé ───────────────────────────────
function buildMenu() {
  const template = [
    {
      label: 'التطبيق',
      submenu: [
        { label: 'الصفحة الرئيسية', click: () => mainWindow?.reload() },
        { type: 'separator' },
        {
          label: 'مجلد البيانات',
          click: () => shell.openPath(app.getPath('userData')),
        },
        { type: 'separator' },
        {
          label: 'خروج',
          role: 'quit',
        },
      ],
    },
    {
      label: 'عرض',
      submenu: [
        { role: 'reload', label: 'تحديث' },
        { role: 'forceReload', label: 'تحديث قسري' },
        { type: 'separator' },
        { role: 'zoomIn', label: 'تكبير' },
        { role: 'zoomOut', label: 'تصغير' },
        { role: 'resetZoom', label: 'حجم افتراضي' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'ملء الشاشة' },
      ],
    },
    {
      label: 'تعليمات',
      submenu: [
        {
          label: 'حول التطبيق',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'EPS Platform',
              message: 'EPS Platform v5.0',
              detail:
                'منصة التربية البدنية والرياضية\n\nأداة إدارية شاملة للأستاذ.',
            });
          },
        },
      ],
    },
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// ── Événements app ──────────────────────────────────
app.whenReady().then(() => {
  createWindow();
  buildMenu();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// Sécurité : bloquer la navigation externe non voulue
app.on('web-contents-created', (_, contents) => {
  contents.on('will-navigate', (event, navigationUrl) => {
    const parsedUrl = new URL(navigationUrl);
    if (parsedUrl.protocol !== 'file:') {
      event.preventDefault();
    }
  });
});
